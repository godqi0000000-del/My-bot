require('dotenv').config();

const ownerNumber = String(process.env.OWNER_NUMBER || '919907049024').replace(/\D/g, '');
const settings = {
  packname: 'Velonika Bot',
  author: 'Spark Blaze',
  botName: 'Velonika Bot',
  botOwner: 'Spark Blaze',
  ownerNumber,
  botNumber: String(process.env.BOT_PHONE_NUMBER || '917501525997').replace(/\D/g, ''),
  giphyApiKey: process.env.GIPHY_API_KEY || '',
  commandMode: 'public',
  maxStoreMessages: 20,
  storeWriteInterval: 10000,
  description: 'Velonika Bot • Group games, virtual currency, and progress tracking',
  version: '3.0.7',
  updateZipUrl: ''
};

module.exports = settings;
