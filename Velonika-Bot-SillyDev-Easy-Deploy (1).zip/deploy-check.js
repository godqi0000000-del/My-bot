'use strict';
const fs = require('fs');
const path = require('path');
try { require('dotenv').config(); } catch { /* npm install has not been run yet; use shell environment */ }
const failures = [];
const warnings = [];
const nodeMajor = Number(process.versions.node.split('.')[0]);
if (nodeMajor < 18) failures.push(`Node.js 18+ required; current version is ${process.versions.node}.`);
if (!String(process.env.OWNER_NUMBER || '').replace(/\D/g, '')) warnings.push('OWNER_NUMBER is empty: owner-only commands will not work until it is configured.');
if (process.env.BOT_PHONE_NUMBER && !/^\d{8,15}$/.test(String(process.env.BOT_PHONE_NUMBER).replace(/\D/g, ''))) failures.push('BOT_PHONE_NUMBER must be an international phone number with 8–15 digits.');
for (const dir of ['session', 'data', 'temp']) {
  const full = path.join(process.cwd(), dir);
  try { fs.mkdirSync(full, { recursive: true }); fs.accessSync(full, fs.constants.R_OK | fs.constants.W_OK); }
  catch (e) { failures.push(`${dir}/ must be writable: ${e.message}`); }
}
for (const warning of warnings) console.warn(`WARNING: ${warning}`);
for (const failure of failures) console.error(`ERROR: ${failure}`);
if (failures.length) process.exit(1);
console.log('Deployment preflight passed. Live WhatsApp pairing and message delivery still require a real-account test.');
