# Quick Start for ZIP Hosting Panels

1. Upload `Velonika-Bot-SillyDev-Easy-Deploy.zip` and extract it in the app's working directory.
2. Select Node.js 20 if available.
3. Install command: `npm install --legacy-peer-deps`
4. Start command: `npm start`
5. Add `OWNER_NUMBER` and optionally `BOT_PHONE_NUMBER` in the host's private environment-variable page. Do not upload a real `.env`.
6. Enable persistent storage and preserve `session/` and `data/` across redeploys/restarts.
7. Start the service and complete WhatsApp linking using the pairing-code flow shown in logs. Never share the pairing code or session folder.

The host must allow long-running Node.js processes. A web/static-only service will not run this bot. Free plans may sleep, restart, restrict background jobs, or lack persistent disks; verify those limits before linking your WhatsApp account.


## Configured private deployment
- Bot number: `917501525997`
- Owner number: `919907049024`
- Pairing-code-only mode is enabled; QR rendering is disabled.
- Copy `.env.example` to `.env` on the host. Never share `.env` or `session/`.
- The ZIP intentionally does not include live WhatsApp session credentials. Link the bot using the pairing code on first launch.
- This is an independent WhatsApp bot, not an official Google product. Virtual currency should remain free-play and non-redeemable.

### dotenv configuration
`dotenv` is declared in `package.json`. Install dependencies with `npm install --legacy-peer-deps`; `settings.js` loads environment variables from `.env` via `require('dotenv').config()`.
