const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    let config = { prefix: '.', botName: settings.botName || 'Velonika Bot', theme: '💜', menuStyle: 'premium' };
    try { config = { ...config, ...require('./custombot').readConfig() }; } catch (_) {}
    const prefix = config.prefix || '.';
    const textIn = (message?.message?.conversation || message?.message?.extendedTextMessage?.text || '').trim();
    const section = textIn.split(/\s+/).slice(1).join(' ').toLowerCase().replace(/^\./, '');
    const sections = {
      home: `╭━━━━━━━━━━━━━━━━━━━━━━╮\n│  ✦ ${config.botName.toUpperCase()} ✦\n│  PROFESSIONAL COMMAND HUB\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n⚡ *One command hub. Clearly organised.*\nChoose a section below by typing:\n• ${prefix}help general\n• ${prefix}help admin\n• ${prefix}help profile\n• ${prefix}help economy\n• ${prefix}help games\n• ${prefix}help media\n• ${prefix}help owner\n\n╭─〔 QUICK ACCESS 〕\n│ ${prefix}ping  · Check response\n│ ${prefix}profile · Your member card\n│ ${prefix}ec help · Eclipcium help\n│ ${prefix}cusbot · Owner customisation\n╰──────────────────────\n
*Context:* Works in groups and private chats where the command is supported. Some actions require admin/owner rights or external services.`,
      general: `╭─〔 🌐 GENERAL 〕\n│ ${prefix}help / ${prefix}menu\n│ ${prefix}ping\n│ ${prefix}alive\n│ ${prefix}owner\n│ ${prefix}joke\n│ ${prefix}quote\n│ ${prefix}fact\n│ ${prefix}weather <city>\n│ ${prefix}news\n│ ${prefix}tts <text>\n│ ${prefix}8ball <question>\n│ ${prefix}groupinfo\n│ ${prefix}staff / ${prefix}admins\n│ ${prefix}jid\n│ ${prefix}trt <text> <lang>\n╰──────────────────────`,
      admin: `╭─〔 🛡️ GROUP ADMIN 〕\n│ ${prefix}kick @user\n│ ${prefix}ban @user\n│ ${prefix}unban @user\n│ ${prefix}promote @user\n│ ${prefix}demote @user\n│ ${prefix}mute [minutes]\n│ ${prefix}unmute\n│ ${prefix}warn @user\n│ ${prefix}warnings @user\n│ ${prefix}delete (reply to message)\n│ ${prefix}tagall\n│ ${prefix}hidetag <text>\n│ ${prefix}antilink\n│ ${prefix}antibadword\n│ ${prefix}welcome <on/off>\n│ ${prefix}goodbye <on/off>\n│ ${prefix}setgname <name>\n│ ${prefix}setgdesc <description>\n│ ${prefix}setgpp (reply to image)\n╰──────────────────────\n⚠️ Group actions require bot admin status and appropriate permissions.`,
      profile: `╭─〔 🪪 MEMBER PROFILE 〕\n│ ${prefix}profile [@user]\n│ ${prefix}me\n│ ${prefix}profilecard\n│ ${prefix}whois @user\n│ ${prefix}setbio <text>\n│ ${prefix}setnickname <name>\n│ ${prefix}setstatus <text>\n│ ${prefix}settitle <title>\n│ ${prefix}setquote <text>\n│ ${prefix}setcolor <theme>\n│ ${prefix}setwebsite <URL>\n│ ${prefix}setprofile\n│ ${prefix}resetprofile\n╰──────────────────────\nProfile fields are stored by the bot; WhatsApp DP access depends on privacy/session availability.`,
      economy: `╭─〔 💠 ECLIPCIUM 〕\n│ ${prefix}ec help\n│ ${prefix}wallet / ${prefix}balance\n│ ${prefix}bank\n│ ${prefix}deposit <amount>\n│ ${prefix}withdraw <amount>\n│ ${prefix}give @user <amount>\n│ ${prefix}daily\n│ ${prefix}work\n│ ${prefix}leaderboard\n│ ${prefix}history\n│ ${prefix}games\n╰──────────────────────\nEclipcium is virtual currency. Use whole-number amounts and verify each transaction reply.`,
      games: `╭─〔 🎮 GAMES & PROGRESS 〕\n│ ${prefix}ec games\n│ ${prefix}slots <amount>\n│ ${prefix}coinflip <amount>\n│ ${prefix}roulette <amount>\n│ ${prefix}blackjack <amount>\n│ ${prefix}trivia\n│ ${prefix}answer <answer>\n│ ${prefix}tictactoe @user\n│ ${prefix}hangman\n│ ${prefix}guess <letter>\n│ ${prefix}truth\n│ ${prefix}dare\n╰──────────────────────\nGame availability and valid arguments may vary by installed module. Virtual-currency play only.`,
      media: `╭─〔 🎨 MEDIA & DOWNLOADS 〕\n│ ${prefix}sticker (reply to image/video)\n│ ${prefix}simage (reply to sticker)\n│ ${prefix}attp <text>\n│ ${prefix}meme\n│ ${prefix}take <packname>\n│ ${prefix}blur (reply to image)\n│ ${prefix}removebg (reply to image)\n│ ${prefix}remini (reply to image)\n│ ${prefix}play <song/query>\n│ ${prefix}instagram <URL>\n│ ${prefix}facebook <URL>\n│ ${prefix}tiktok <URL>\n│ ${prefix}github <query>\n╰──────────────────────\nDownload and image commands may depend on third-party services.`,
      owner: `╭─〔 ⚙️ OWNER CONTROL 〕\n│ ${prefix}cusbot · Open custom studio\n│ ${prefix}setprefix <symbols>\n│ ${prefix}setbotdp (reply to image)\n│ ${prefix}setbotname <name>\n│ ${prefix}setdc <about text>\n│ ${prefix}setbotstatus <text>\n│ ${prefix}settheme <emoji>\n│ ${prefix}setmenu <premium|compact>\n│ ${prefix}setwelcome <text>\n│ ${prefix}setgoodbye <text>\n│ ${prefix}setpublic <on|off>\n│ ${prefix}settyping <on|off>\n│ ${prefix}setautoread <on|off>\n│ ${prefix}setreactions <on|off>\n│ ${prefix}setcurrencyname <name>\n│ ${prefix}setcurrencysymbol <symbol>\n│ ${prefix}resetcustom\n╰──────────────────────\nOwner-only. Type ${prefix}cusbot for the current customisation menu.`
    };
    const valid = Object.keys(sections);
    const output = sections[section] || (section ? `Unknown help section: *${section}*\nAvailable: ${valid.join(', ')}\n\n${sections.home}` : sections.home);
    try {
      const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
      if (!section && fs.existsSync(imagePath)) {
        await sock.sendMessage(chatId, { image: fs.readFileSync(imagePath), caption: output }, { quoted: message });
      } else {
        await sock.sendMessage(chatId, { text: output }, { quoted: message });
      }
    } catch (error) {
      console.error('[help menu]', error);
      await sock.sendMessage(chatId, { text: output }, { quoted: message });
    }
}

module.exports = helpCommand;