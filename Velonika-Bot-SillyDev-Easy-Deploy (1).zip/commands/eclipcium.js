// Eclipcium (Ec) virtual group currency. Integer-only accounting; no floating-point money.
const fs = require('fs');
const path = require('path');
const dbDir = path.join(process.cwd(), 'data');
const dbFile = path.join(dbDir, 'eclipcium.json');

function load() {
  try {
    const parsed = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || !parsed.groups || typeof parsed.groups !== 'object') throw new Error('Invalid database');
    return parsed;
  } catch (err) {
    if (err.code !== 'ENOENT') console.error('[Eclipcium] Could not read database; starting empty:', err.message);
    return { version: 1, groups: {} };
  }
}
function save(db) {
  fs.mkdirSync(dbDir, { recursive: true });
  const tmp = dbFile + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(tmp, dbFile);
}
function safeBalance(value) { return Number.isSafeInteger(value) && value >= 0 ? value : 0; }
function account(db, groupId, jid, name = 'Member') {
  db.groups[groupId] ||= { users: {}, ledger: [] };
  const group = db.groups[groupId];
  group.users ||= {};
  group.ledger ||= [];
  if (!group.users[jid]) group.users[jid] = { name: name || 'Member', wallet: 1000, bank: 0, createdAt: new Date().toISOString() };
  const user = group.users[jid];
  user.wallet = safeBalance(user.wallet);
  user.bank = safeBalance(user.bank);
  if (name && name !== 'Member') user.name = name;
  if (!user.createdAt) user.createdAt = new Date().toISOString();
  return user;
}
const fmt = n => `${safeBalance(n).toLocaleString('en-US')} Ec`;
const parseAmount = value => {
  if (typeof value !== 'string' || !/^\d+$/.test(value)) return NaN;
  const n = Number(value);
  return Number.isSafeInteger(n) ? n : NaN;
};
function log(group, type, from, to, amount, note = '') {
  group.ledger.unshift({ type, from, to, amount, note, at: new Date().toISOString() });
  group.ledger = group.ledger.slice(0, 200);
}
function memberId(jid) { return String(jid || '').split('@')[0]; }

async function eclipciumCommand(sock, chatId, senderId, message, args, isGroup) {
  const reply = async text => sock.sendMessage(chatId, { text }, { quoted: message });
  // Currency data is scoped to the current chat: group balances stay group-specific,
  // while a direct message gets a separate private wallet and leaderboard.
  const chatScope = String(chatId || '');
  if (!chatScope.endsWith('@g.us') && !chatScope.endsWith('@s.whatsapp.net')) {
    return reply('⚠️ Eclipcium works in WhatsApp groups and direct chats only.');
  }

  const db = load();
  db.groups[chatId] ||= { users: {}, ledger: [] };
  const group = db.groups[chatId];
  group.users ||= {}; group.ledger ||= [];
  const senderName = message.pushName || 'Member';
  const me = account(db, chatId, senderId, senderName);
  const rawSub = String(args[0] || 'help').toLowerCase();
  const shortAliases = { daily:'daily', bonus:'daily', work:'work', h:'help', cmd:'help', b:'balance', bal:'balance', w:'wallet', p:'profile', prof:'profile', bk:'bank', dep:'deposit', d:'deposit', wd:'withdraw', g:'give', tr:'give', lb:'leaderboard', rank:'leaderboard', hist:'history', tx:'transactions', gm:'games', arcade:'games', s:'slots', sl:'slots', cf:'coinflip', rf:'roulette', bj:'blackjack', bc:'baccarat', pl:'plinko', mn:'mines', kn:'keno', sc:'scratch', pk:'poker', hi:'hilo', wh:'wheel', jp:'jackpot', l7:'lucky7', os:'oddseven', db:'dicebattle', cr:'crown', cd:'carddraw', np:'numberpick', ts:'treasure', cp:'cups', mul:'multiplier', w2:'wheel2', hl:'highlow', lc:'luckycoin', dp:'dicepair', rc:'royalcard', cw:'colorwheel', vc:'vault', sf:'safecrack', cry:'crystal', met:'meteor', com:'comet', ecg:'eclipsegame', gr:'goldrush', prl:'pearl', drg:'dragon', phx:'phoenix', zod:'zodiac', ms:'moonshot', stf:'starfall', bb:'bonusball', lg:'luckygrid', wc:'wordchain', ag:'anagram', cap:'capitals', sci:'science', hs:'historyquiz', syn:'synonym', opp:'opposite', spl:'spelling', seq:'sequence', pat:'pattern', qc:'quickcalc', logc:'logic', anq:'animalquiz', fq:'foodquiz', sq:'sportquiz', tq:'techquiz', geo:'geography', tf:'truefalse', ce:'countemoji', typ:'typing', mem2:'memory2', rp:'rps', q:'guess', trv:'trivia', ma:'math', rd:'riddle', em:'emoji', scr:'scramble', mem:'memory', od:'odd', col:'color', an:'animal', pln:'planet', fg:'flag', rx:'reaction' };
  const sub = shortAliases[rawSub] || rawSub;

  if (sub === 'help' || sub === 'commands') return reply(
    '💷 *ECLIPCIUM — Ec CURRENCY SYSTEM*\n\n' +
    '`.ec` / `.wallet` / `.balance` — wallet + bank balance\n' +
    '`.profile` — your member profile\n' +
    '`.bank` — bank account details\n' +
    '`.deposit 500` or `.deposit all` — wallet → bank\n' +
    '`.withdraw 200` or `.withdraw all` — bank → wallet\n' +
    '`.give @member 250` — send Ec to a member\n' +
    '`.leaderboard` — richest members in this GC\n' +
    '`.ec daily` — claim a daily Ec allowance (24h cooldown)\n' +
    '`.ec work` — earn a small work reward (1h cooldown)\n' +
    '`.history` — recent transactions\n' +
    '`.ec games` / `.ec gm` — free-play arcade games\n' +
    '*Shortcuts:* `.bal` `.w` `.p` `.bk` `.dep 500` `.wd 200` `.g @member 50` `.lb` `.hist` `.gm` `.sl` `.cf heads` `.bj` `.trv` `.ma` `.rd`\n\n' +
    'New profiles receive *1,000 Ec* once. Balances are whole Ec only. Each GC has a separate economy.\n\n*ECLIPCIUM SYSTEM STATUS:* virtual-only currency · integer-safe ledger · group-isolated balances · no real-money value.'
  );

  if (['balance', 'bal', 'wallet'].includes(sub)) {
    save(db);
    return reply(`╭━━━〔 💠 ECLIPCIUM WALLET 〕━━━╮\n│ Account: ${me.name}\n├─────────────────────────────\n│ 👛 Wallet      ${fmt(me.wallet)}\n│ 🏦 Bank        ${fmt(me.bank)}\n│ 💎 Total       ${fmt(me.wallet + me.bank)}\n├─────────────────────────────\n│ Currency: Ec • Virtual only\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\nUse .ec help for account commands.`);
  }
  if (sub === 'profile' || sub === 'me') {
    save(db);
    return reply(`╭━━━〔 🪪 ECLIPCIUM ID 〕━━━╮\n│ Member: ${me.name}\n│ Account: ${memberId(senderId)}\n├─────────────────────────────\n│ 👛 Wallet   ${fmt(me.wallet)}\n│ 🏦 Bank     ${fmt(me.bank)}\n│ 💎 Net worth ${fmt(me.wallet + me.bank)}\n│ 📅 Joined   ${me.createdAt.slice(0,10)}\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n🏛️ Eclipcium Ledger • Group-scoped account`);
  }
  if (sub === 'bank') {
    save(db);
    return reply(`🏦 *Eclipcium Central Bank*\nAccount holder: ${me.name}\nAccount ID: EC-${Buffer.from(`${chatId}:${senderId}`).toString('hex').slice(0, 10).toUpperCase()}\nAvailable in bank: ${fmt(me.bank)}\nWallet balance: ${fmt(me.wallet)}\nTotal assets: ${fmt(me.wallet + me.bank)}\nTransactions are recorded in this GC's ledger.`);
  }

  if (sub === 'deposit' || sub === 'withdraw') {
    const source = sub === 'deposit' ? 'wallet' : 'bank';
    const target = sub === 'deposit' ? 'bank' : 'wallet';
    const amount = String(args[1] || '').toLowerCase() === 'all' ? me[source] : parseAmount(args[1]);
    if (!Number.isSafeInteger(amount) || amount <= 0) return reply(`❌ Enter a positive whole Ec amount.\nExample: .${sub} 500\nOr use: .${sub} all`);
    if (me[source] < amount) return reply(`❌ Insufficient ${source} balance. Available: ${fmt(me[source])}. No money was moved.`);
    if (!Number.isSafeInteger(me[target] + amount)) return reply('❌ This transaction exceeds the supported balance limit. No money was moved.');
    me[source] -= amount;
    me[target] += amount;
    log(group, sub, senderId, senderId, amount);
    save(db);
    return reply(`✅ *${sub === 'deposit' ? 'Deposit successful' : 'Withdrawal successful'}*\nAmount: ${fmt(amount)}\n👛 Wallet: ${fmt(me.wallet)}\n🏦 Bank: ${fmt(me.bank)}\n💰 Total: ${fmt(me.wallet + me.bank)}\n🧾 Transaction recorded.`);
  }

  if (['give', 'send', 'pay'].includes(sub)) {
    const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const targetId = mentions.find(id => id !== senderId);
    const amountToken = args.slice(1).find(x => /^\d+$/.test(String(x)));
    const amount = parseAmount(amountToken);
    if (!targetId) return reply('❌ Tag the recipient. Example: .give @member 250');
    if (targetId === senderId) return reply('❌ You cannot send Ec to yourself.');
    if (!Number.isSafeInteger(amount) || amount <= 0) return reply('❌ Amount must be a positive whole number. Example: .give @member 250');
    if (me.wallet < amount) return reply(`❌ Insufficient wallet funds. Available: ${fmt(me.wallet)}. No money was moved.`);
    const targetName = targetId.split('@')[0];
    const target = account(db, chatId, targetId, targetName);
    if (!Number.isSafeInteger(target.wallet + amount)) return reply('❌ Recipient balance limit reached. No money was moved.');
    me.wallet -= amount;
    target.wallet += amount;
    log(group, 'transfer', senderId, targetId, amount);
    save(db);
    return reply(`✅ *Ec transfer successful*\n👤 From: ${me.name}\n👤 To: ${target.name}\n💷 Sent: ${fmt(amount)}\nYour wallet: ${fmt(me.wallet)}\nRecipient wallet: ${fmt(target.wallet)}\n💰 Your total assets: ${fmt(me.wallet + me.bank)}`);
  }

  if (sub === 'daily' || sub === 'work') {
    const now = Date.now();
    me.claims ||= {};
    const key = sub;
    const cooldown = sub === 'daily' ? 24 * 60 * 60 * 1000 : 60 * 60 * 1000;
    const last = Number(me.claims[key] || 0);
    if (now - last < cooldown) {
      const remaining = cooldown - (now - last);
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.ceil((remaining % 3600000) / 60000);
      return reply(`⏳ *${sub === 'daily' ? 'Daily allowance' : 'Work shift'} already claimed.*\nTry again in ${hours ? `${hours}h ` : ''}${minutes}m.`);
    }
    const amount = sub === 'daily' ? 150 : 35 + Math.floor(Math.random() * 46);
    if (!Number.isSafeInteger(me.wallet + amount)) return reply('❌ Wallet limit reached; no reward was added.');
    me.claims[key] = now;
    me.wallet += amount;
    log(group, sub, 'SYSTEM', senderId, amount, 'Virtual economy allowance');
    save(db);
    return reply(`╭━━━〔 ✦ *ECLIPCIUM CENTRAL* 〕━━━╮\n${sub === 'daily' ? '🎁 DAILY ALLOWANCE' : '🧰 WORK SHIFT COMPLETE'}\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n✅ Credited: *+${fmt(amount)}*\n👛 Wallet: ${fmt(me.wallet)}\n🏦 Bank: ${fmt(me.bank)}\n💎 Net worth: ${fmt(me.wallet + me.bank)}\n\n${sub === 'daily' ? 'Next daily claim in 24 hours.' : 'Next work shift in 1 hour.'}\n🛡️ Virtual currency only · no real-money value.`);
  }

  if (sub === 'leaderboard' || sub === 'top') {
    save(db);
    const rows = Object.entries(group.users).sort((a, b) => (safeBalance(b[1].wallet) + safeBalance(b[1].bank)) - (safeBalance(a[1].wallet) + safeBalance(a[1].bank))).slice(0, 10);
    return reply('🏆 *Eclipcium GC Leaderboard*\n\n' + (rows.length ? rows.map(([id, u], i) => `${i + 1}. ${u.name || memberId(id)} — ${fmt(safeBalance(u.wallet) + safeBalance(u.bank))}`).join('\n') : 'No members yet.') + '\n\nTotal = wallet + bank');
  }
  if (sub === 'history' || sub === 'transactions') {
    save(db);
    const rows = group.ledger.slice(0, 10);
    return reply('📜 *Recent Ec Transactions*\n\n' + (rows.length ? rows.map(t => `• ${String(t.type).toUpperCase()}: ${fmt(t.amount)} — ${new Date(t.at).toLocaleString()}`).join('\n') : 'No transactions recorded yet.'));
  }
  // Free-play arcade: games may miss a reward, but never stake or deduct existing Ec.
  const gameHelp =
    '╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n' +
    '      ✦ *ECLIPCIUM ARCADE* ✦\n' +
    '╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n' +
    '   *83 FREE-PLAY EXPERIENCES*\n' +
    '   Play · Learn · Earn bonus Ec\n\n' + +
    '🎰 *ARCADE / LUCKY GAMES*\n' +
    '`.ec spin` · `.ec s` Slots · `.ec dice` Dice · `.ec cf heads` Coin flip\n' +
    '`.ec rf red` Roulette · `.ec bj` Blackjack · `.ec bc` Baccarat\n' +
    '`.ec pl` Plinko · `.ec mn 3` Mines · `.ec kn 7` Keno · `.ec sc` Scratch · `.ec triple` Triple slots\n' +
    '`.ec pk` Poker · `.ec hi high` High/low · `.ec wh` Wheel · `.ec jp` Jackpot\n' +
    '`.ec l7` Lucky 7 · `.ec os odd` Odd/even · `.ec db` Dice battle\n' +
    '`.ec cr` Crown · `.ec cd` Card draw · `.ec np 4` Number pick · `.ec ts` Treasure · `.ec redblack red` Red/black\n' +
    '`.ec cp 2` Cups · `.ec mul` Multiplier · `.ec w2` Bonus wheel · `.ec hl high` High/low\n' +
    '`.ec lc heads` Lucky coin · `.ec dp` Dice pair · `.ec rc` Royal card · `.ec cw gold` Color wheel\n' +
    '`.ec vc` Vault · `.ec sf 2` Safe crack · `.ec cry` Crystal · `.ec met` Meteor · `.ec com` Comet\n' +
    '`.ec ecg` Eclipse · `.ec gr` Gold rush · `.ec prl` Pearl · `.ec drg` Dragon · `.ec phx` Phoenix\n' +
    '`.ec zod` Zodiac · `.ec ms` Moonshot · `.ec stf` Starfall · `.ec bb 4` Bonus ball · `.ec lg 5` Lucky grid\n\n' +
    '🧠 *QUIZ / SKILL GAMES*\n' +
    '`.ec rp rock` Rock-paper-scissors · `.ec q 4` Guess · `.ec trv` Trivia · `.ec ma` Math · `.ec rd` Riddle\n' +
    '`.ec em` Emoji puzzle · `.ec scr` Scramble · `.ec mem 247` Memory · `.ec wc star` Word chain · `.ec ag apple` Anagram\n' +
    '`.ec cap tokyo` Capitals · `.ec sci h2o` Science · `.ec hs rome` History · `.ec syn glad` Synonym\n' +
    '`.ec opp cold` Opposite · `.ec spl library` Spelling · `.ec seq 12` Sequence · `.ec pat 8` Pattern · `.ec qc 100` Quick calc\n' +
    '`.ec logc yes` Logic · `.ec anq cheetah` Animal quiz · `.ec fq avocado` Food quiz · `.ec sq badminton` Sports quiz\n' +
    '`.ec tq h2o` Tech quiz · `.ec geo pacific` Geography · `.ec tf true` True/false · `.ec ce 3` Count emoji · `.ec typ velonika` Typing · `.ec mem2 4816` Memory II\n' +
    '`.ec od even` Odd/even · `.ec col blue` Color · `.ec an` Animal · `.ec pln` Planet · `.ec fg` Flag · `.ec rx` Reaction · `.ec higher high` Higher/lower\n\n' +
    '🛡️ *FAIR PLAY*\n' +
    '• Games never deduct Ec from your wallet or bank.\n' +
    '• Correct / lucky rounds can earn a fixed bonus (up to 500 Ec).\n' +
    '• Most games have a 30-second cooldown; `.ec spin` resets daily.\n' +
    '• Use `.ec balance`, `.ec profile`, `.ec bank`, `.ec leaderboard` or `.ec history` for account tools.\n' +
    '• Use `.ec daily` and `.ec work` for scheduled virtual-currency rewards.';
  if (['games', 'arcade', 'gamehelp'].includes(sub)) return reply(gameHelp);

  const casinoGames = ['spin','slots','dice','coinflip','roulette','blackjack','baccarat','plinko','mines','keno','scratch','poker','hilo','wheel','jackpot','lucky7','oddseven','dicebattle','crown','carddraw','triple','redblack','numberpick','treasure','cups','multiplier','wheel2','highlow','luckycoin','dicepair','royalcard','colorwheel','vault','safecrack','crystal','meteor','comet','eclipsegame','goldrush','pearl','dragon','phoenix','zodiac','moonshot','starfall','bonusball','luckygrid'];
  const funGames = ['rps','guess','trivia','math','riddle','emoji','scramble','memory','odd','higher','color','animal','planet','flag','reaction','wordchain','anagram','capitals','science','historyquiz','synonym','opposite','spelling','sequence','pattern','quickcalc','logic','animalquiz','foodquiz','sportquiz','techquiz','geography','truefalse','countemoji','typing','memory2'];
  if ([...casinoGames, ...funGames].includes(sub)) {
    const now = Date.now();
    me.gameCooldowns ||= {};
    const key = sub;
    const waitMs = sub === 'spin' ? 24 * 60 * 60 * 1000 : 30 * 1000;
    const last = Number(me.gameCooldowns[key] || 0);
    if (now - last < waitMs) return reply(`⏳ Try again in ${Math.ceil((waitMs - (now-last))/1000)} seconds. ${sub === 'spin' ? 'The wheel resets daily.' : 'This game has a 30-second cooldown.'}`);
    const rand = n => Math.floor(Math.random() * n);
    const pick = arr => arr[rand(arr.length)];
    const validChoice = (value, choices, example) => choices.includes(String(value || '').toLowerCase()) ? String(value).toLowerCase() : null;
    let prize = 0, detail = '';
    const cards = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
    const colors = ['red','black'];
    const animals = ['cat','dog','tiger','elephant','dolphin'];
    const planets = ['Mercury','Venus','Earth','Mars','Jupiter','Saturn','Uranus','Neptune'];
    const emojis = ['🐼','🦊','🐸','🐙','🦄'];
    me.pendingGames ||= {};
    if (sub === 'spin') { prize = pick([0,10,20,25,50,75,100,150]); detail = `🎡 Lucky wheel: ${prize} Ec ${prize ? 'reward!' : 'No reward this time.'}`; }
    else if (sub === 'slots' || sub === 'triple') { const sy=['🍒','🍋','🔔','💎','⭐','🍀']; const a=pick(sy),b=pick(sy),c=pick(sy); prize=a===b&&b===c?(a==='💎'?200:100):(a===b||b===c||a===c?20:0); detail=`🎰 ${a} | ${b} | ${c}\n${prize?'Combination matched!':'No match — no Ec lost.'}`; }
    else if (sub === 'dice') { const n=1+rand(6); prize=n===6?50:n>=4?15:0; detail=`🎲 You rolled ${n}. ${prize?'Nice roll!':'No reward this round.'}`; }
    else if (sub === 'coinflip') { const c=validChoice(args[1],['heads','tails']); if(!c)return reply('🪙 Use `.ec coinflip heads` or `.ec coinflip tails`.'); const out=pick(['heads','tails']); prize=c===out?25:0; detail=`🪙 Coin: ${out}. ${prize?'Correct call!':'Not this time.'}`; }
    else if (sub === 'roulette' || sub === 'redblack') { const c=validChoice(args[1],sub==='roulette'?['red','black','green']:colors); if(!c)return reply(sub==='roulette'?'🎡 Choose `.ec roulette red`, `black`, or `green`.':'🔴 Choose `.ec redblack red` or `.ec redblack black`.'); const out=pick(['red','black','red','black','green']); prize=c===out?(out==='green'?100:25):0; detail=`🎡 Ball landed on ${out}. ${prize?'You called it!':'No reward this round.'}`; }
    else if (sub === 'blackjack') { const a=1+rand(10),b=1+rand(10),dealer=12+rand(9),total=a+b; prize=total===21?100:total>dealer&&total<=21?35:0; detail=`🃏 Your hand: ${a} + ${b} = ${total}; dealer: ${dealer}. ${prize?'You beat the dealer!':'Dealer wins this round — no Ec lost.'}`; }
    else if (sub === 'baccarat') { const player=rand(10),banker=rand(10); prize=player===banker?15:player>banker?30:0; detail=`🂡 Player ${player} | Banker ${banker}. ${player===banker?'Tie!':player>banker?'Player wins!':'Banker wins — no Ec lost.'}`; }
    else if (sub === 'plinko') { const slots=[0,5,10,20,30,50,100]; prize=pick(slots); detail=`🔻 Plinko landed in the ${prize} Ec pocket.`; }
    else if (sub === 'mines') { const n=Number(args[1]||1); if(!Number.isInteger(n)||n<1||n>5)return reply('💣 Choose 1–5 safe picks: `.ec mines 3`. Free play; no stake.'); const hit=rand(5)<n; prize=hit?0:Math.min(100,n*15); detail=`💎 ${hit?'A mine appeared! Round over, but your Ec stays safe.':`You found ${n} safe gem${n===1?'':'s'}!`}`; }
    else if (sub === 'keno') { const target=1+rand(10),guess=Number(args[1]); if(!Number.isInteger(guess)||guess<1||guess>10)return reply('🎟️ Pick a number 1–10: `.ec keno 7`.'); prize=guess===target?75:0; detail=`🎟️ Drawn number: ${target}. ${prize?'Keno hit!':'No match.'}`; }
    else if (sub === 'scratch') { const sy=['🍀','⭐','💎','🍒']; const a=pick(sy),b=pick(sy),c=pick(sy); prize=a===b&&b===c?75:a===b||b===c||a===c?15:0; detail=`🪙 Scratch card: ${a} ${b} ${c}. ${prize?'You found a match!':'No match.'}`; }
    else if (sub === 'poker') { const hand=[pick(cards),pick(cards),pick(cards)]; prize=hand[0]===hand[1]||hand[1]===hand[2]||hand[0]===hand[2]?40:hand.every(x=>['A','K','Q','J'].includes(x))?25:0; detail=`♠️ Your three-card hand: ${hand.join(' • ')}. ${prize?'Nice hand!':'No winning combination.'}`; }
    else if (sub === 'hilo' || sub === 'higher') { const c=validChoice(args[1],['high','low']); if(!c)return reply('🃏 Choose `.ec hilo high` or `.ec hilo low`.'); const n=1+rand(13); prize=(c==='high'?n>=8:n<=6)?25:0; detail=`🃏 Card value: ${n}. ${prize?'Correct prediction!':'Wrong prediction.'}`; }
    else if (sub === 'wheel') { prize=pick([0,10,20,30,50,100]); detail=`🎡 Prize wheel selected ${prize} Ec.`; }
    else if (sub === 'jackpot') { const n=rand(100); prize=n===7?250:n<20?25:0; detail=`🎰 Jackpot number: ${n}. ${prize===250?'MEGA JACKPOT!':prize?'Small prize!':'No jackpot this round.'}`; }
    else if (sub === 'lucky7') { const n=1+rand(10); prize=n===7?70:0; detail=`🍀 Lucky number: ${n}. ${prize?'Lucky seven!':'Not seven this time.'}`; }
    else if (sub === 'oddseven') { const c=validChoice(args[1],['odd','even']); if(!c)return reply('🎲 Use `.ec oddseven odd` or `.ec oddseven even`.'); const n=1+rand(6); prize=(n%2===0?'even':'odd')===c?20:0; detail=`🎲 Roll: ${n} (${n%2===0?'even':'odd'}). ${prize?'Correct!':'No reward.'}`; }
    else if (sub === 'dicebattle') { const a=1+rand(6),b=1+rand(6); prize=a>b?30:a===b?10:0; detail=`🎲 You rolled ${a}; rival rolled ${b}. ${a>b?'You win!':a===b?'Draw!':'Rival wins.'}`; }
    else if (sub === 'crown') { const c=pick(['👑','💎','🪙']); prize=c==='👑'?60:c==='💎'?20:0; detail=`👑 Crown draw: ${c}. ${prize?'You found a prize!':'No prize this time.'}`; }
    else if (sub === 'carddraw') { const c=pick(cards); prize=['A','K','Q','J'].includes(c)?30:c==='7'?50:0; detail=`🂠 You drew ${c}. ${prize?'Lucky card!':'No reward.'}`; }
    else if (sub === 'numberpick') { const n=1+rand(5),g=Number(args[1]); if(!Number.isInteger(g)||g<1||g>5)return reply('🔢 Pick 1–5: `.ec numberpick 3`.'); prize=n===g?50:0; detail=`🔢 Number was ${n}. ${prize?'Exact match!':'No match.'}`; }
    else if (sub === 'treasure') { const c=pick(['🪨','🪙','💎','🪵','👑']); prize=({'🪙':20,'💎':60,'👑':100})[c]||0; detail=`🗺️ You opened a chest and found ${c}.`; }
    else if (sub === 'cups') { const g=Number(args[1]); if(!Number.isInteger(g)||g<1||g>3)return reply('🥤 Pick cup 1, 2, or 3: `.ec cups 2`.'); const n=1+rand(3); prize=g===n?45:0; detail=`🥤 Prize was under cup ${n}. ${prize?'Great pick!':'Empty cup.'}`; }
    else if (sub === 'multiplier') { const m=pick([0,1,1,2,3,5]); prize=m*10; detail=`🚀 Free multiplier: x${m}. Reward ${prize} Ec.`; }
    else if (sub === 'rps') { const c=validChoice(args[1],['rock','paper','scissors']); if(!c)return reply('⚔️ Use `.ec rps rock`, `paper`, or `scissors`.'); const b=pick(['rock','paper','scissors']); const win=(c==='rock'&&b==='scissors')||(c==='paper'&&b==='rock')||(c==='scissors'&&b==='paper'); prize=win?30:c===b?5:0; detail=`⚔️ You: ${c}; bot: ${b}. ${win?'You win!':c===b?'Draw!':'Bot wins.'}`; }
    else if (sub === 'guess') { const g=Number(args[1]); if(!Number.isInteger(g)||g<1||g>5)return reply('🔢 Guess 1–5: `.ec guess 4`.'); const n=1+rand(5); prize=g===n?50:0; detail=`🔢 Number was ${n}. ${prize?'Perfect guess!':'No match.'}`; }
    else if (sub === 'trivia') { let q=me.pendingGames.trivia; if(!q||!args[1]) { q=pick([{q:'Which planet is known as the Red Planet?',a:'mars'},{q:'How many sides does a hexagon have?',a:'6'},{q:'What is the largest ocean?',a:'pacific'},{q:'How many days are in a leap year?',a:'366'}]); me.pendingGames.trivia=q; if(!args[1])return (save(db), reply(`🧠 ${q.q}
Reply with .ec trivia your-answer`)); } prize=String(args[1]||'').toLowerCase()===q.a?35:0; detail=`🧠 ${q.q}
Correct answer: ${q.a}. ${prize?'Correct!':'Not quite.'}`; delete me.pendingGames.trivia; }
    else if (sub === 'math') { let q=me.pendingGames.math; if(!q||args[1]===undefined) { const a=2+rand(18),b=2+rand(18); q={a,b,answer:a+b}; me.pendingGames.math=q; if(args[1]===undefined)return (save(db), reply(`➕ Solve: ${a} + ${b} = ?\nReply with your answer using the .ec math command`)); } prize=Number(args[1])===q.answer?20:0; detail=`➕ ${q.a} + ${q.b} = ${q.answer}. ${prize?'Correct maths!':'Try another round.'}`; delete me.pendingGames.math; }
    else if (sub === 'riddle') { let q=me.pendingGames.riddle; if(!q||!args[1]) { q=pick([{q:'What has keys but no locks?',a:'piano'},{q:'What gets wetter as it dries?',a:'towel'},{q:'What has a face and two hands but no arms?',a:'clock'}]); me.pendingGames.riddle=q; if(!args[1])return (save(db), reply(`🧩 ${q.q}\nReply with .ec riddle your-answer`)); } prize=String(args[1]||'').toLowerCase()===q.a?35:0; detail=`🧩 Correct answer: ${q.a}. ${prize?'Solved!':'Not solved this time.'}`; delete me.pendingGames.riddle; }
    else if (sub === 'emoji') { let q=me.pendingGames.emoji; if(!q||!args[1]) { q=pick([{e:'🐝 + 🍯',a:'honey'},{e:'🌧️ + 🌈',a:'rainbow'},{e:'🦷 + 🪥',a:'toothbrush'},{e:'🌙 + ⭐',a:'night'}]); me.pendingGames.emoji=q; if(!args[1])return (save(db), reply(`😀 Guess the word: ${q.e}\nReply with .ec emoji your-answer`)); } prize=String(args[1]||'').toLowerCase()===q.a?25:0; detail=`😀 Puzzle ${q.e}; answer: ${q.a}. ${prize?'Solved!':'Not quite.'}`; delete me.pendingGames.emoji; }
    else if (sub === 'scramble') { let q=me.pendingGames.scramble; if(!q||!args[1]) { q=pick([{s:'PPAEL',a:'apple'},{s:'NOMOL',a:'lemon'},{s:'RTAES',a:'stare'},{s:'NILPTEA',a:'planet'}]); me.pendingGames.scramble=q; if(!args[1])return (save(db), reply(`🔤 Unscramble: ${q.s}\nReply with .ec scramble your-word`)); } prize=String(args[1]||'').toLowerCase()===q.a?30:0; detail=`🔤 Answer: ${q.a}. ${prize?'Correct!':'Keep practicing.'}`; delete me.pendingGames.scramble; }
    else if (sub === 'memory') { let seq=me.pendingGames.memory; if(!seq||!args[1]) { seq=pick(['247','583','916','428','731']); me.pendingGames.memory=seq; if(!args[1])return (save(db), reply(`🧠 Memorize this sequence: *${seq}*\nThen send .ec memory ${seq}`)); } prize=String(args[1]||'')===seq?35:0; detail=`🧠 Sequence was ${seq}. ${prize?'Memory champion!':'Not exact this time.'}`; delete me.pendingGames.memory; }
    else if (sub === 'odd') { const c=validChoice(args[1],['odd','even']); if(!c)return reply('🔢 Use `.ec odd odd` or `.ec odd even`.'); const n=1+rand(20); prize=(n%2===0?'even':'odd')===c?15:0; detail=`🔢 Number: ${n} (${n%2===0?'even':'odd'}). ${prize?'Correct!':'No reward.'}`; }
    else if (sub === 'color') { const c=validChoice(args[1],['red','blue','green','yellow']); if(!c)return reply('🎨 Choose `.ec color red`, `blue`, `green`, or `yellow`.'); const out=pick(['red','blue','green','yellow']); prize=c===out?25:0; detail=`🎨 Color was ${out}. ${prize?'Matched!':'No match.'}`; }
    else if (sub === 'animal') { let q=me.pendingGames.animal; if(!q||!args[1]) { q=pick([{e:'🐱',a:'cat'},{e:'🐶',a:'dog'},{e:'🐯',a:'tiger'},{e:'🐘',a:'elephant'},{e:'🐬',a:'dolphin'}]); me.pendingGames.animal=q; if(!args[1])return (save(db), reply(`🐾 Name this animal: ${q.e}\nReply with .ec animal cat (or the animal name)`)); } prize=String(args[1]||'').toLowerCase()===q.a?40:0; detail=`🐾 Animal was ${q.a}. ${prize?'Correct guess!':'No match.'}`; delete me.pendingGames.animal; }
    else if (sub === 'planet') { let q=me.pendingGames.planet; if(!q||!args[1]) { q=pick([{e:'🪐',a:'saturn'},{e:'🔴',a:'mars'},{e:'🌍',a:'earth'}]); me.pendingGames.planet=q; if(!args[1])return (save(db), reply(`🪐 Guess the planet from the clue ${q.e}\nReply with .ec planet your-answer`)); } prize=String(args[1]||'').toLowerCase()===q.a?40:0; detail=`🪐 Answer: ${q.a}. ${prize?'Correct!':'No match.'}`; delete me.pendingGames.planet; }
    else if (sub === 'flag') { let q=me.pendingGames.flag; if(!q||!args[1]) { q=pick([{flag:'🇮🇳',a:'india'},{flag:'🇯🇵',a:'japan'},{flag:'🇫🇷',a:'france'},{flag:'🇧🇷',a:'brazil'}]); me.pendingGames.flag=q; if(!args[1])return (save(db), reply(`🏳️ Which country does this flag belong to? ${q.flag}\nReply with .ec flag your-answer`)); } prize=String(args[1]||'').toLowerCase()===q.a?30:0; detail=`🏳️ Flag ${q.flag} = ${q.a}. ${prize?'Correct!':'Not quite.'}`; delete me.pendingGames.flag; }
    else if (sub === 'reaction') { const score=rand(101); prize=score>=85?30:score>=60?10:0; detail=`⚡ Reaction simulator score: ${score}/100. ${prize?'Great reflex score!':'Warm up and try again.'}`; }
    // Additional free-play arcade games. Multipliers apply to a fixed bonus, never to a user's balance or stake.
    else if (sub === 'wheel2') { const m=pick([0,2,2,4,8,10,25]); prize=m*10; detail=`🎡 Bonus wheel: x${m}. Fixed bonus reward: ${prize} Ec.`; }
    else if (sub === 'highlow') { const c=validChoice(args[1],['high','low']); if(!c)return reply('🃏 Use `.ec highlow high` or `.ec highlow low`.'); const n=1+rand(13); prize=(c==='high'?n>=8:n<=6)?40:0; detail=`🃏 Card value ${n}; ${prize?'prediction correct!':'prediction missed.'}`; }
    else if (sub === 'luckycoin') { const c=validChoice(args[1],['heads','tails']); if(!c)return reply('🪙 Use `.ec luckycoin heads` or `.ec luckycoin tails`.'); const out=pick(['heads','tails']); prize=c===out?30:0; detail=`🪙 Coin landed ${out}.`; }
    else if (sub === 'dicepair') { const a=1+rand(6),b=1+rand(6); prize=a===b?80:(a+b>=9?25:0); detail=`🎲 Pair roll ${a} + ${b} = ${a+b}; ${prize?'bonus unlocked!':'no bonus this round.'}`; }
    else if (sub === 'royalcard') { const c=pick(cards); prize=c==='A'?100:['K','Q','J'].includes(c)?40:0; detail=`👑 Royal card: ${c}.`; }
    else if (sub === 'colorwheel') { const c=validChoice(args[1],['red','blue','green','gold']); if(!c)return reply('🎨 Choose red, blue, green, or gold: `.ec colorwheel gold`.'); const out=pick(['red','blue','green','gold']); prize=c===out?60:0; detail=`🎡 Color wheel landed on ${out}.`; }
    else if (sub === 'vault') { const n=rand(4); prize=[0,15,35,75][n]; detail=`🔐 Vault opened: ${['empty vault','bronze vault','silver vault','gold vault'][n]}.`; }
    else if (sub === 'safecrack') { const g=Number(args[1]); if(!Number.isInteger(g)||g<1||g>4)return reply('🔒 Choose code 1–4: `.ec safecrack 2`.'); const n=1+rand(4); prize=g===n?80:0; detail=`🔐 Safe code was ${n}.`; }
    else if (sub === 'crystal') { const c=pick(['🪨','🔹','🔷','💎']); prize=({'🪨':0,'🔹':10,'🔷':35,'💎':90})[c]; detail=`🔮 Crystal reveal: ${c}.`; }
    else if (sub === 'meteor') { const n=rand(10); prize=n>=9?100:n>=6?25:0; detail=`☄️ Meteor score ${n}/9.`; }
    else if (sub === 'comet') { const n=rand(5); prize=[0,10,20,40,75][n]; detail=`🌠 Comet trail bonus: ${prize} Ec.`; }
    else if (sub === 'eclipsegame') { const c=pick(['🌑','🌒','🌕']); prize=c==='🌑'?70:c==='🌕'?25:0; detail=`🌘 Eclipse phase: ${c}.`; }
    else if (sub === 'goldrush') { const c=pick(['🪙','🪙','🪨','💰','💎']); prize=({'🪙':15,'🪨':0,'💰':50,'💎':100})[c]; detail=`⛏️ Gold rush found ${c}.`; }
    else if (sub === 'pearl') { const n=1+rand(3); prize=[0,20,60][n-1]; detail=`🦪 Shell ${n} contained ${prize?'a pearl':'no pearl'}.`; }
    else if (sub === 'dragon') { const c=pick(['🐉','🔥','🪨']); prize=c==='🐉'?90:c==='🔥'?20:0; detail=`🐉 Dragon cave encounter: ${c}.`; }
    else if (sub === 'phoenix') { const c=pick(['🔥','🪶','🌫️']); prize=c==='🔥'?70:c==='🪶'?25:0; detail=`🔥 Phoenix sign: ${c}.`; }
    else if (sub === 'zodiac') { const c=pick(['aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces']); prize=['leo','libra','aquarius'].includes(c)?35:10; detail=`♒ Lucky zodiac today: ${c}.`; }
    else if (sub === 'moonshot') { const m=pick([0,1,2,4,8,10,25]); prize=m*4; detail=`🚀 Moonshot bonus x${m}: ${prize} Ec.`; }
    else if (sub === 'starfall') { const n=rand(6); prize=[0,10,15,25,50,100][n]; detail=`🌟 Starfall reward: ${prize} Ec.`; }
    else if (sub === 'bonusball') { const g=Number(args[1]); if(!Number.isInteger(g)||g<1||g>6)return reply('🎱 Pick a ball 1–6: `.ec bonusball 4`.'); const n=1+rand(6); prize=g===n?75:0; detail=`🎱 Bonus ball was ${n}.`; }
    else if (sub === 'luckygrid') { const g=Number(args[1]); if(!Number.isInteger(g)||g<1||g>9)return reply('🟪 Pick grid cell 1–9: `.ec luckygrid 5`.'); const n=1+rand(9); prize=g===n?90:0; detail=`🟪 Lucky cell was ${n}.`; }
    else if (sub === 'wordchain') { let q=me.pendingGames.wordchain; if(!q||!args[1]) { q=pick([{q:'Say a word starting with S',a:['star','sun','sky','stone']},{q:'Say a fruit',a:['apple','mango','banana','orange']},{q:'Say an animal',a:['tiger','cat','dog','lion']}]); me.pendingGames.wordchain=q; if(!args[1])return (save(db),reply(`🔗 ${q.q}. Reply: .ec wordchain your-word`)); } prize=q.a.includes(String(args[1]).toLowerCase())?25:0; detail=`🔗 ${prize?'Valid answer!':'Not in the accepted answers.'}`; delete me.pendingGames.wordchain; }
    else if (sub === 'anagram') { let q=me.pendingGames.anagram; if(!q||!args[1]) { q=pick([{s:'RTAES',a:'stare'},{s:'LPEAP',a:'apple'},{s:'NOMEL',a:'lemon'},{s:'RABIN',a:'brain'}]); me.pendingGames.anagram=q; if(!args[1])return (save(db),reply(`🔤 Unscramble ${q.s}: .ec anagram answer`)); } prize=String(args[1]).toLowerCase()===q.a?35:0; detail=`🔤 ${prize?'Correct anagram!':`Answer: ${q.a}.`}`; delete me.pendingGames.anagram; }
    else if (sub === 'capitals') { let q=me.pendingGames.capitals; if(!q) { q=pick([{c:'India',a:'new delhi'},{c:'Japan',a:'tokyo'},{c:'France',a:'paris'},{c:'Bangladesh',a:'dhaka'},{c:'Nepal',a:'kathmandu'}]); me.pendingGames.capitals=q; } if(!args[1])return (save(db),reply(`🌍 *Capital challenge*
What is the capital of ${q.c}?
Reply: .ec capitals your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?35:0; detail=`🌍 Capital of ${q.c}: ${q.a}.`; delete me.pendingGames.capitals; }
    else if (sub === 'science') { let q=me.pendingGames.science; if(!q) { q=pick([{q:'Chemical symbol for water?',a:'h2o'},{q:'How many legs does an insect have?',a:'6'},{q:'Which star is nearest Earth?',a:'sun'}]); me.pendingGames.science=q; } if(!args[1])return (save(db),reply(`🔬 ${q.q}
Use .ec science your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?35:0; detail=`🔬 Answer: ${q.a}.`; delete me.pendingGames.science; }
    else if (sub === 'historyquiz') { let q=me.pendingGames.historyquiz; if(!q) { q=pick([{q:'Which ancient civilization built the pyramids at Giza?',a:'egyptians'},{q:'Who was the first person to walk on the Moon?',a:'neil armstrong'},{q:'Which city was the Roman Empire centered on?',a:'rome'}]); me.pendingGames.historyquiz=q; } if(!args[1])return (save(db),reply(`📚 ${q.q}
Use .ec historyquiz your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?35:0; detail=`📚 Answer: ${q.a}.`; delete me.pendingGames.historyquiz; }
    else if (sub === 'synonym') { let q=me.pendingGames.synonym; if(!q) { q=pick([{q:'happy',a:['glad','joyful','cheerful']},{q:'fast',a:['quick','rapid','swift']},{q:'tiny',a:['small','little','miniature']}]); me.pendingGames.synonym=q; } if(!args[1])return (save(db),reply(`📖 Give a synonym for “${q.q}”.
Use .ec synonym your-answer`)); const answer=String(args.slice(1).join(' ')).toLowerCase(); prize=q.a.includes(answer)?25:0; detail=`📖 Accepted answers: ${q.a.join(', ')}.`; delete me.pendingGames.synonym; }
    else if (sub === 'opposite') { let q=me.pendingGames.opposite; if(!q) { q=pick([{q:'hot',a:'cold'},{q:'early',a:'late'},{q:'empty',a:'full'}]); me.pendingGames.opposite=q; } if(!args[1])return (save(db),reply(`↔️ What is the opposite of “${q.q}”?
Use .ec opposite your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?25:0; detail=`↔️ Answer: ${q.a}.`; delete me.pendingGames.opposite; }
    else if (sub === 'spelling') { let q=me.pendingGames.spelling; if(!q) { q=pick([{q:'A place with books',a:'library'},{q:'Opposite of difficult',a:'easy'},{q:'Color of grass',a:'green'}]); me.pendingGames.spelling=q; } if(!args[1])return (save(db),reply(`✍️ Spell: ${q.q}.
Use .ec spelling your-word`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?25:0; detail=`✍️ Correct spelling: ${q.a}.`; delete me.pendingGames.spelling; }
    else if (sub === 'sequence') { let q=me.pendingGames.sequence; if(!q) { const a=2+rand(5); q={seq:[a,a+2,a+4],answer:a+6}; me.pendingGames.sequence=q; } if(!args[1])return (save(db),reply(`🔢 Continue: ${q.seq.join(', ')}, ?
Use .ec sequence your-number`)); prize=Number(args[1])===q.answer?30:0; detail=`🔢 Next number: ${q.answer}.`; delete me.pendingGames.sequence; }
    else if (sub === 'pattern') { let q=me.pendingGames.pattern; if(!q) { const a=1+rand(5); q={seq:[a,a*2,a*3],answer:a*4}; me.pendingGames.pattern=q; } if(!args[1])return (save(db),reply(`🧩 Continue the pattern: ${q.seq.join(', ')}, ?
Use .ec pattern your-number`)); prize=Number(args[1])===q.answer?30:0; detail=`🧩 Next number: ${q.answer}.`; delete me.pendingGames.pattern; }
    else if (sub === 'quickcalc') { let q=me.pendingGames.quickcalc; if(!q) { const a=2+rand(20),b=2+rand(20); q={a,b,answer:a*b}; me.pendingGames.quickcalc=q; } if(!args[1])return (save(db),reply(`⚡ Quick calc: ${q.a} × ${q.b} = ?
Use .ec quickcalc your-answer`)); prize=Number(args[1])===q.answer?35:0; detail=`⚡ Answer: ${q.answer}.`; delete me.pendingGames.quickcalc; }
    else if (sub === 'logic') { let q=me.pendingGames.logic; if(!q) { q=pick([{q:'If all bloops are razzies and all razzies are lazzies, are all bloops lazzies?',a:'yes'},{q:'How many months have 28 days?',a:'12'},{q:'What comes next: Monday, Tuesday, Wednesday, ?',a:'thursday'}]); me.pendingGames.logic=q; } if(!args[1])return (save(db),reply(`🧠 ${q.q}
Use .ec logic your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?35:0; detail=`🧠 Answer: ${q.a}.`; delete me.pendingGames.logic; }
    else if (sub === 'animalquiz') { let q=me.pendingGames.animalquiz; if(!q) { q=pick([{q:'Fastest land animal?',a:'cheetah'},{q:'Largest mammal?',a:'blue whale'},{q:'Which bird is known for mimicking speech?',a:'parrot'}]); me.pendingGames.animalquiz=q; } if(!args[1])return (save(db),reply(`🐾 ${q.q}
Use .ec animalquiz your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?30:0; detail=`🐾 Answer: ${q.a}.`; delete me.pendingGames.animalquiz; }
    else if (sub === 'foodquiz') { let q=me.pendingGames.foodquiz; if(!q) { q=pick([{q:'Which fruit is famous for having a crown of leaves?',a:'pineapple'},{q:'Main ingredient in guacamole?',a:'avocado'},{q:'Which grain is used to make popcorn?',a:'corn'}]); me.pendingGames.foodquiz=q; } if(!args[1])return (save(db),reply(`🍽️ ${q.q}
Use .ec foodquiz your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?30:0; detail=`🍽️ Answer: ${q.a}.`; delete me.pendingGames.foodquiz; }
    else if (sub === 'sportquiz') { let q=me.pendingGames.sportquiz; if(!q) { q=pick([{q:'How many players per team are on court in basketball?',a:'5'},{q:'Which sport uses a shuttlecock?',a:'badminton'},{q:'How many rings are on the Olympic symbol?',a:'5'}]); me.pendingGames.sportquiz=q; } if(!args[1])return (save(db),reply(`🏅 ${q.q}
Use .ec sportquiz your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?30:0; detail=`🏅 Answer: ${q.a}.`; delete me.pendingGames.sportquiz; }
    else if (sub === 'techquiz') { let q=me.pendingGames.techquiz; if(!q) { q=pick([{q:'What does CPU stand for?',a:'central processing unit'},{q:'What does HTML stand for?',a:'hypertext markup language'},{q:'Binary uses which two digits?',a:'0 and 1'}]); me.pendingGames.techquiz=q; } if(!args[1])return (save(db),reply(`💻 ${q.q}
Use .ec techquiz your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?35:0; detail=`💻 Answer: ${q.a}.`; delete me.pendingGames.techquiz; }
    else if (sub === 'geography') { let q=me.pendingGames.geography; if(!q) { q=pick([{q:'Largest ocean?',a:'pacific'},{q:'Which continent is Brazil in?',a:'south america'},{q:'Mount Everest lies in which mountain range?',a:'himalayas'}]); me.pendingGames.geography=q; } if(!args[1])return (save(db),reply(`🗺️ ${q.q}
Use .ec geography your-answer`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q.a?35:0; detail=`🗺️ Answer: ${q.a}.`; delete me.pendingGames.geography; }
    else if (sub === 'truefalse') { let q=me.pendingGames.truefalse; if(!q) { q=pick([{q:'The Sun is a star.',a:'true'},{q:'A triangle has four sides.',a:'false'},{q:'Earth has one natural moon.',a:'true'}]); me.pendingGames.truefalse=q; } if(!args[1])return (save(db),reply(`✅❌ ${q.q}
Answer with .ec truefalse true or false`)); prize=String(args[1]).toLowerCase()===q.a?20:0; detail=`✅❌ Correct answer: ${q.a}.`; delete me.pendingGames.truefalse; }
    else if (sub === 'countemoji') { let q=me.pendingGames.countemoji; if(!q) { const n=1+rand(5),e=pick(['⭐','🍀','💎','🔥']); q={n,e}; me.pendingGames.countemoji=q; } if(!args[1])return (save(db),reply(`🔎 Count these symbols: ${Array(q.n).fill(q.e).join(' ')}
Use .ec countemoji your-number`)); prize=Number(args[1])===q.n?25:0; detail=`🔎 There were ${q.n} symbols.`; delete me.pendingGames.countemoji; }
    else if (sub === 'typing') { let q=me.pendingGames.typing; if(!q) { q=pick(['velonika','eclipcium','galaxy','starlight','adventure']); me.pendingGames.typing=q; } if(!args[1])return (save(db),reply(`⌨️ Type this word exactly: *${q}*
Use .ec typing your-word`)); prize=String(args.slice(1).join(' ')).toLowerCase()===q?20:0; detail=`⌨️ Target word: ${q}.`; delete me.pendingGames.typing; }
    else if (sub === 'memory2') { let q=me.pendingGames.memory2; if(!q) { q=pick(['4816','2759','6304','8192']); me.pendingGames.memory2=q; } if(!args[1])return (save(db),reply(`🧠 Memorize *${q}*, then send .ec memory2 your-number`)); prize=String(args[1])===q?35:0; detail=`🧠 Sequence was ${q}.`; delete me.pendingGames.memory2; }
    if (!Number.isSafeInteger(prize) || prize < 0 || prize > 500) prize = 0;
    me.gameCooldowns[key] = now;
    if (!Number.isSafeInteger(me.wallet + prize)) return reply('❌ Wallet limit reached; no reward was added.');
    me.wallet += prize;
    if (prize > 0) log(group, `game:${sub}`, 'SYSTEM', senderId, prize, detail);
    save(db);
    return reply(`╭━━━〔 💷 *ECLIPCIUM RESULT* 〕━━━╮\n${detail}\n\n🎁 Bonus: *${fmt(prize)}*\n👛 Wallet: ${fmt(me.wallet)}\n🏦 Bank: ${fmt(me.bank)}\n💎 Total assets: ${fmt(me.wallet + me.bank)}\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n🛡️ Free play · no Ec wagered or deducted.`);
  }
  return reply('❓ Unknown currency command. Send `.ec help` to see all Eclipcium commands.');
}
module.exports = eclipciumCommand;
