async function githubCommand(sock, chatId, message) {
  const text = [
    '*✦ Velonika Bot — Project Info ✦*',
    '',
    'Created by *Spark Blaze*',
    'Virtual currency: *Eclipcium (Ec)*',
    'Games: *83 free-play games*',
    '',
    'Repository URL has not been configured for this installation.',
    'The bot works independently of a public GitHub repository.'
  ].join('\n');
  await sock.sendMessage(chatId, { text }, { quoted: message });
}

module.exports = githubCommand;
