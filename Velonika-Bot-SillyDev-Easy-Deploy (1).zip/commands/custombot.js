const fs = require('fs');
const path = require('path');
const settings = require('../settings');
const CONFIG_PATH = path.join(process.cwd(), 'data', 'botconfig.json');
function readConfig(){ try { return JSON.parse(fs.readFileSync(CONFIG_PATH,'utf8')); } catch { return { prefix: '.', botName: settings.botName || 'Velonika Bot', description: settings.description || 'Velonika Bot • Eclipcium Virtual Currency', theme: '💜', menuStyle: 'premium', packname: settings.packname || 'Velonika Bot', author: settings.author || 'Spark Blaze', welcomeText: 'Welcome to the group!', goodbyeText: 'Goodbye! Take care.', publicMode: true, reactions: true, typing: true, readReceipts: false }; } }
function writeConfig(c){ fs.mkdirSync(path.dirname(CONFIG_PATH),{recursive:true}); fs.writeFileSync(CONFIG_PATH, JSON.stringify(c,null,2)); }
function clean(s, max=500){ return String(s||'').trim().slice(0,max); }
function isOwnerOnly(message, settings){
 if (message?.key?.fromMe) return true;
 const sender = String(message?.key?.participant || message?.key?.remoteJid || '').split(':')[0].split('@')[0];
 let list=[]; try { list=JSON.parse(fs.readFileSync(path.join(process.cwd(),'data','owner.json'),'utf8')); } catch {}
 if (!Array.isArray(list)) list=[list];
 const configured=String(settings.ownerNumber||'').replace(/\D/g,'');
 return (configured && sender===configured) || list.some(x=>String(x).replace(/\D/g,'')===sender);
}
const ownerHelp = (c) => `╭━━━〔 ✦ VELONIKA CUSTOM STUDIO ✦ 〕━━━╮\n│ Creator: Spark Blaze\n│ Prefix: ${c.prefix}\n│ Theme: ${c.theme}\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n⚙️ *OWNER-ONLY CUSTOMIZATION*\n${c.prefix}setprefix <symbol>  (1–3 symbols; e.g. !, ¥, √, ∆, ×, ✓, @, #, ~)\n${c.prefix}botdp (reply to image)\n${c.prefix}setdc <about text>\n${c.prefix}setbotname <name>\n${c.prefix}setbotstatus <text>\n${c.prefix}settheme <emoji>\n${c.prefix}setmenu <premium|compact>\n${c.prefix}setpackname <name>\n${c.prefix}setauthor <name>\n${c.prefix}setwelcome <text>\n${c.prefix}setgoodbye <text>\n${c.prefix}setdescription <text>\n${c.prefix}setpublic <on|off>\n${c.prefix}settyping <on|off>\n${c.prefix}setautoread <on|off>\n${c.prefix}setreactions <on|off>\n${c.prefix}settimezone <IANA timezone>\n${c.prefix}setlanguage <en|bn|hi>\n${c.prefix}setfooter <text>\n${c.prefix}setownername <name>\n${c.prefix}setcurrencyname <name>\n${c.prefix}setcurrencysymbol <symbol>\n${c.prefix}setdaily <amount>\n${c.prefix}setworkmin <amount>\n${c.prefix}setworkmax <amount>\n${c.prefix}setcooldown <seconds>\n${c.prefix}setbotmode <public|private>\n${c.prefix}resetcustom\n${c.prefix}cusbot`;
const textSettings = {
 setbotname:['botName','Bot name',40], setbotstatus:['status','Bot status',139], settheme:['theme','Theme emoji/symbol',12], setmenu:['menuStyle','Menu style',20], setpackname:['packname','Sticker pack name',60], setauthor:['author','Sticker author',60], setwelcome:['welcomeText','Welcome text',500], setgoodbye:['goodbyeText','Goodbye text',500], setdescription:['description','Description',300], settimezone:['timezone','Timezone',80], setlanguage:['language','Language',8], setfooter:['footer','Menu footer',120], setownername:['ownerName','Owner display name',60], setcurrencyname:['currencyName','Currency name',40], setcurrencysymbol:['currencySymbol','Currency symbol',8]
};
const boolSettings = {setpublic:'publicMode',settyping:'typing',setautoread:'readReceipts',setreactions:'reactions'};
async function handleCustomBot(sock, chatId, senderId, message, args, rawCommand){
 const cmd=String(rawCommand||'').toLowerCase();
 const config=readConfig();
 const known=['cusbot','setprefix','botdp','setbotdp','setdc','setbotname','setbotstatus','settheme','setmenu','setpackname','setauthor','setwelcome','setgoodbye','setdescription','setpublic','settyping','setautoread','setreactions','settimezone','setlanguage','setfooter','setownername','setcurrencyname','setcurrencysymbol','setdaily','setworkmin','setworkmax','setcooldown','setbotmode','resetcustom'];
 if(!known.includes(cmd)) return false;
 if(!isOwnerOnly(message,settings)) { await sock.sendMessage(chatId,{text:'🔒 *Owner access only*\nCustomization settings can only be changed by the bot owner.'},{quoted:message}); return true; }
 const value=clean(args.join(' '),600);
 const reply=async(text)=>sock.sendMessage(chatId,{text},{quoted:message});
 if(cmd==='cusbot'){ await reply(ownerHelp(config)); return true; }
 if(cmd==='setprefix'){
   const p=value;
   if(!p || [...p].length>3 || !/^[^\p{L}\p{N}\s]{1,3}$/u.test(p) || p==='.') { await reply('❌ Choose 1–3 punctuation/symbol characters, e.g. !, §, ¥, √, ∆, ×, ✓, @, #, or ~. Letters, numbers and spaces are not allowed; dot remains reserved for recovery.'); return true; }
   config.prefix=p; writeConfig(config); await reply(`✅ Prefix updated to *${p}*\nExample: ${p}help\nThe new prefix is saved across restarts.`); return true;
 }
 if(cmd==='botdp' || cmd==='setbotdp'){ 
   let img=message.message?.imageMessage;
   const quoted=message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
   if(!img && quoted) img=quoted.imageMessage || quoted?.viewOnceMessage?.message?.imageMessage;
   if(!img){ await reply('🖼️ Reply to an image with the current prefix + botdp, or send an image with the command caption.'); return true; }
   try {
     const { downloadContentFromMessage }=require('@whiskeysockets/baileys');
     const stream=await downloadContentFromMessage(img,'image'); const chunks=[]; for await (const chunk of stream) chunks.push(chunk);
     const buf=Buffer.concat(chunks); if(buf.length>5*1024*1024){ await reply('❌ Image is over 5 MB. Please use a smaller image.'); return true; }
     const jid=sock.user?.id; if(!jid) throw new Error('Bot session is not connected');
     await sock.updateProfilePicture(jid,buf); await reply('✅ Bot profile picture updated.');
   } catch(e){ console.error('[custombot botdp]',e); await reply('❌ Could not update profile photo. Check the connection and try a JPEG/PNG image.'); }
   return true;
 }
 if(cmd==='setdc'){
   if(!value) { await reply(`Current description: ${config.description||settings.description}\nUsage: ${config.prefix}setdc <text>`); return true; }
   try { await sock.updateProfileStatus(value.slice(0,139)); config.description=value.slice(0,300); writeConfig(config); await reply('✅ Bot About/status updated and saved.'); }
   catch(e){ console.error('[custombot setdc]',e); config.description=value.slice(0,300); writeConfig(config); await reply('⚠️ Description saved locally, but WhatsApp did not confirm the profile status update.'); }
   return true;
 }
 if(cmd==='resetcustom') { const fresh={prefix:'.',botName:'Velonika Bot',description:'Velonika Bot • Eclipcium Virtual Currency',theme:'💜',menuStyle:'premium',packname:'Velonika Bot',author:'Spark Blaze',welcomeText:'Welcome to the group!',goodbyeText:'Goodbye! Take care.',publicMode:true,reactions:true,typing:true,readReceipts:false}; writeConfig(fresh); await reply('♻️ Custom settings reset. Prefix is now .'); return true; }
 if(textSettings[cmd]) { const [key,label,max]=textSettings[cmd]; if(!value){ await reply(`${label}: ${config[key]||'(not set)'}\nUsage: ${config.prefix}${cmd} <value>`); return true; } if(cmd==='setmenu'&&!['premium','compact'].includes(value.toLowerCase())){ await reply('Choose menu style: premium or compact.'); return true; } config[key]=value.slice(0,max); writeConfig(config); if(cmd==='setbotname'){ try{ await sock.updateProfileName(config[key]); }catch(e){ console.error(e); } } if(cmd==='setbotstatus'){ try{ await sock.updateProfileStatus(config[key].slice(0,139)); }catch(e){ console.error(e); } } if(cmd==='setpackname') global.packname=config[key]; if(cmd==='setauthor') global.author=config[key]; await reply(`✅ ${label} saved: *${config[key]}*`); return true; }
 if(boolSettings[cmd]) { const v=value.toLowerCase(); if(!['on','off','true','false'].includes(v)){ await reply(`Usage: ${config.prefix}${cmd} <on|off>`); return true; } config[boolSettings[cmd]]=['on','true'].includes(v); writeConfig(config); await reply(`✅ ${cmd.slice(3)} set to *${config[boolSettings[cmd]]?'ON':'OFF'}*. Some options may require matching feature support in the main bot.`); return true; }
 const numeric={setdaily:['dailyReward',0,1000000],setworkmin:['workMin',0,1000000],setworkmax:['workMax',0,1000000],setcooldown:['cooldownSeconds',0,86400]};
 if(numeric[cmd]) { const [key,min,max]=numeric[cmd], n=Number(value); if(!Number.isSafeInteger(n)||n<min||n>max){ await reply(`Enter a whole number from ${min} to ${max}.`); return true; } config[key]=n; writeConfig(config); await reply(`✅ ${key} saved as ${n}. Note: this setting affects behavior only where the corresponding feature reads botconfig.json.`); return true; }
 if(cmd==='setbotmode'){ if(!['public','private'].includes(value.toLowerCase())){ await reply(`Usage: ${config.prefix}setbotmode <public|private>`); return true; } config.publicMode=value.toLowerCase()==='public'; writeConfig(config); await reply(`✅ Bot mode saved: ${value.toLowerCase()}.`); return true; }
 return true;
}
module.exports={handleCustomBot,readConfig};
