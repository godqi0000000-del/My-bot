const path = require('path');
const fs = require('fs');
const projectRoot = path.resolve(__dirname, '..');
const os = require('os');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'eclipcium-tests-'));
process.chdir(root);
const cmd = require(path.join(projectRoot, 'commands/eclipcium.js'));
const dbfile = path.join(root,'data','eclipcium.json');
const names = ['spin','slots','dice','coinflip','roulette','blackjack','baccarat','plinko','mines','keno','scratch','poker','hilo','wheel','jackpot','lucky7','oddseven','dicebattle','crown','carddraw','triple','redblack','numberpick','treasure','cups','multiplier','wheel2','highlow','luckycoin','dicepair','royalcard','colorwheel','vault','safecrack','crystal','meteor','comet','eclipsegame','goldrush','pearl','dragon','phoenix','zodiac','moonshot','starfall','bonusball','luckygrid','rps','guess','trivia','math','riddle','emoji','scramble','memory','odd','higher','color','animal','planet','flag','reaction','wordchain','anagram','capitals','science','historyquiz','synonym','opposite','spelling','sequence','pattern','quickcalc','logic','animalquiz','foodquiz','sportquiz','techquiz','geography','truefalse','countemoji','typing','memory2'];
const aliases = {h:'help',cmd:'help',b:'balance',bal:'balance',w:'wallet',p:'profile',prof:'profile',bk:'bank',dep:'deposit',d:'deposit',wd:'withdraw',g:'give',tr:'give',lb:'leaderboard',rank:'leaderboard',hist:'history',tx:'transactions',gm:'games',arcade:'games',s:'slots',sl:'slots',cf:'coinflip',rf:'roulette',bj:'blackjack',bc:'baccarat',pl:'plinko',mn:'mines',kn:'keno',sc:'scratch',pk:'poker',hi:'hilo',wh:'wheel',jp:'jackpot',l7:'lucky7',os:'oddseven',db:'dicebattle',cr:'crown',cd:'carddraw',np:'numberpick',ts:'treasure',cp:'cups',mul:'multiplier',w2:'wheel2',hl:'highlow',lc:'luckycoin',dp:'dicepair',rc:'royalcard',cw:'colorwheel',vc:'vault',sf:'safecrack',cry:'crystal',met:'meteor',com:'comet',ecg:'eclipsegame',gr:'goldrush',prl:'pearl',drg:'dragon',phx:'phoenix',zod:'zodiac',ms:'moonshot',stf:'starfall',bb:'bonusball',lg:'luckygrid',wc:'wordchain',ag:'anagram',cap:'capitals',sci:'science',hs:'historyquiz',syn:'synonym',opp:'opposite',spl:'spelling',seq:'sequence',pat:'pattern',qc:'quickcalc',logc:'logic',anq:'animalquiz',fq:'foodquiz',sq:'sportquiz',tq:'techquiz',geo:'geography',tf:'truefalse',ce:'countemoji',typ:'typing',mem2:'memory2',rp:'rps',q:'guess',trv:'trivia',ma:'math',rd:'riddle',em:'emoji',scr:'scramble',mem:'memory',od:'odd',col:'color',an:'animal',pln:'planet',fg:'flag',rx:'reaction'};
let count=0, failures=[];
async function run(sub,args=[],user='u'+count,group='g@g.us') {
  let last=''; const sock={sendMessage:async (_chat,payload)=>{last=payload.text||''; return {};}};
  const msg={pushName:user,message:{extendedTextMessage:{contextInfo:{mentionedJid:[]}}}};
  await cmd(sock,group,user+'@s.whatsapp.net',msg,[sub,...args],true);
  count++; return last;
}
(async()=>{
 try {
  // all 83 canonical game handlers are callable and return a useful response
  for(const n of names){const r=await run(n,[],`game_${n}`); if(!r || r.includes('Unknown currency command')) failures.push(`${n}: missing/unknown response`);}
  // every short game alias resolves to its intended canonical handler
  for(const [a,n] of Object.entries(aliases)) {
   const args = n==='coinflip'?['heads']:n==='roulette'?['red']:n==='hilo'||n==='higher'||n==='highlow'?['high']:n==='oddseven'||n==='odd'?['odd']:n==='rps'?['rock']:n==='guess'?['3']:n==='keno'?['3']:n==='numberpick'?['3']:n==='cups'?['2']:n==='mines'?['3']:n==='bonusball'?['3']:n==='luckygrid'?['5']:n==='safecrack'?['2']:n==='colorwheel'?['gold']:n==='luckycoin'?['heads']:n==='wordchain'?['star']:n==='anagram'?['apple']:n==='capitals'?['tokyo']:n==='science'?['h2o']:n==='historyquiz'?['rome']:n==='synonym'?['glad']:n==='opposite'?['cold']:n==='spelling'?['library']:n==='sequence'?['12']:n==='pattern'?['8']:n==='quickcalc'?['100']:n==='logic'?['yes']:n==='animalquiz'?['cheetah']:n==='foodquiz'?['avocado']:n==='sportquiz'?['badminton']:n==='techquiz'?['h2o']:n==='geography'?['pacific']:n==='truefalse'?['true']:n==='countemoji'?['3']:n==='typing'?['velonika']:n==='memory2'?['4816']:[];
   const r=await run(n,args,`alias_${a}`); if(!r || r.includes('Unknown currency command')) failures.push(`${a}->${n}: missing/unknown response`);
  }
  // Multi-turn quizzes must preserve the exact question between prompt and answer.
  const pendingTests = ['capitals','science','historyquiz','synonym','opposite','spelling','sequence','pattern','quickcalc','logic','animalquiz','foodquiz','sportquiz','techquiz','geography','truefalse','countemoji','typing','memory2','trivia','math','riddle','emoji','scramble','memory','animal','planet','flag','wordchain','anagram'];
  for (const n of pendingTests) {
    const user = `pending_${n}`;
    const prompt = await run(n, [], user);
    const db = JSON.parse(fs.readFileSync(dbfile, 'utf8'));
    const saved = db.groups['g@g.us']?.users?.[`${user}@s.whatsapp.net`]?.pendingGames?.[n];
    if (!prompt || !saved) { failures.push(`${n}: question was not saved`); continue; }
    let answer;
    if (n === 'synonym') answer = saved.a[0];
    else if (n === 'sequence' || n === 'pattern' || n === 'quickcalc' || n === 'math') answer = saved.answer;
    else if (n === 'countemoji') answer = saved.n;
    else if (n === 'typing' || n === 'memory2' || n === 'memory') answer = saved;
    else if (n === 'wordchain') answer = saved.a[0];
    else answer = saved.a;
    const result = await run(n, [String(answer)], user);
    if (!result.includes('ECLIPCIUM RESULT')) failures.push(`${n}: saved answer did not complete round`);
  }
  // Account flow: balance, deposit/withdraw, transfer and history should reply.
  const user='econ_user@s.whatsapp.net', group='econ@g.us';
  const call=async(args)=>{let t='';const sock={sendMessage:async(_c,p)=>{t=p.text||'';}};await cmd(sock,group,user,{pushName:'Economy Tester',message:{extendedTextMessage:{contextInfo:{mentionedJid:[]}}}},args,true);return t;};
  for(const a of [['balance'],['deposit','250'],['withdraw','100'],['leaderboard'],['history'],['profile'],['bank'],['games']]) {const r=await call(a);if(!r)failures.push('economy '+a[0]+': empty response');}
  // Daily and work reward commands credit the wallet once per cooldown and reply on repeats.
  for (const n of ['daily','work']) {
    const user = `claim_${n}@s.whatsapp.net`, group = `claim_${n}@g.us`;
    const callClaim = async () => { let t=''; const sock={sendMessage:async(_c,p)=>{t=p.text||'';}}; await cmd(sock,group,user,{pushName:'Claim Tester',message:{}},[n],true); return t; };
    const first = await callClaim();
    const second = await callClaim();
    if (!first.includes('Credited:') || !second.includes('already claimed')) failures.push(`${n}: reward/cooldown failed`);
  }
  // All direct-command tokens added to the message router must be present in the route regex and alias table.
  const router = fs.readFileSync(path.join(projectRoot,'main.js'),'utf8');
  for (const a of ['w2','hl','lc','dp','rc','cw','vc','sf','cry','met','com','ecg','gr','prl','drg','phx','zod','ms','stf','bb','lg','wc','ag','cap','sci','hs','syn','opp','spl','seq','pat','qc','logc','anq','fq','sq','tq','geo','tf','ce','typ','mem2','daily','work']) {
    if (!router.includes(`${a}:`)) failures.push(`router alias missing: ${a}`);
  }
  // Inbox support: direct chats receive a separate private Eclipcium wallet.
  let privateText=''; await cmd({sendMessage:async(_c,p)=>{privateText=p.text||'';}},'dm_user@s.whatsapp.net','dm_user@s.whatsapp.net',{pushName:'DM Tester',message:{}},['balance'],false); if(!privateText) failures.push('DM balance did not reply');
  const dmDb = JSON.parse(fs.readFileSync(dbfile, 'utf8')); if (!dmDb.groups['dm_user@s.whatsapp.net']?.users?.['dm_user@s.whatsapp.net']) failures.push('DM wallet scope not saved');
  // Menu image is packaged and referenced by the menu command and profile updater.
  if (!fs.existsSync(path.join(projectRoot,'assets','bot_image.jpg'))) failures.push('bot menu image missing');
  const helpSource = fs.readFileSync(path.join(projectRoot,'commands/help.js'),'utf8'); if (!helpSource.includes('bot_image.jpg')) failures.push('menu image not referenced');
  const indexSource = fs.readFileSync(path.join(projectRoot,'index.js'),'utf8'); if (!indexSource.includes('updateProfilePicture')) failures.push('profile image updater missing');
  // Alias inventory consistency
  const source=fs.readFileSync(path.join(projectRoot,'commands/eclipcium.js'),'utf8');
  if(!source.includes('ECLIPCIUM ARCADE')||!source.includes('83 FREE-PLAY EXPERIENCES')) failures.push('arcade UI missing');
  console.log(JSON.stringify({canonicalGames:names.length,aliases:Object.keys(aliases).length,pendingQuestionGames:pendingTests.length,invocations:count,failures},null,2));
  process.exitCode=failures.length?1:0;
 } catch(e){console.error(e.stack);process.exitCode=1;} finally { try{fs.rmSync(root,{recursive:true,force:true});}catch{} }
})();
