# Velonika Bot — SillyDev deployment guide

## Before you start
This bot needs a persistent Node.js worker, outbound internet access, and persistent writable storage. A static-site service is not suitable. No package can guarantee 100% uptime or successful WhatsApp linking on every host.

## SillyDev panel setup
1. Stop the existing bot and back up its private `session/` and `data/` folders.
2. Upload `Velonika-Bot-SillyDev-Easy-Deploy.zip` and extract it into the app root (the same directory should contain `package.json`, `index.js`, and `settings.js`).
3. Choose Node.js 20 or newer.
4. Set the install command to `npm install --legacy-peer-deps --no-audit --no-fund`.
5. Set the start command to `npm start`.
6. In the panel's **private environment variables**, set:
   - `OWNER_NUMBER=919907049024`
   - `BOT_PHONE_NUMBER=917501525997`
   Do not post pairing codes, `.env`, or session files publicly.
7. Ensure `session/` and `data/` are persistent across restarts/redeploys. Do not delete the session directory after linking.
8. Run `npm run deploy:check` if the panel provides a shell, then start the worker and follow the pairing-code flow in the logs.

## If it fails
- `Cannot find module 'NAME'`: read the exact module name in the error, then rerun the install command from the project root.
- `settings.js` missing: confirm `settings.js` and `index.js` are both in the app root, not one directory deeper.
- Pairing doesn't start: confirm the bot number is digits only and that the host allows persistent long-running processes.
- Repeated logouts: verify persistent storage is enabled for `session/`.
- Native/media module errors: use Node.js 20 and ensure the host provides required system packages; some media commands may need `ffmpeg`.
- Do not use `npm run start:fresh` unless you deliberately want to reset the WhatsApp session.

## Notes
The archive does not include a live WhatsApp session or private API keys. First-time linking is required. Virtual currency is intended for free-play only and has no real-world cash value. This is an independent project, not an official Google product.
